<!-- <body onload="loadImg()">
    <div class="boxcenter">
        <div class="row mb header">
            <h1>Siêu thị trực tuyến</h1>
        </div>
        <div class="row mb menu">
            <ul>
                <li><a href="">Trang chủ</a></li>
                <li><a href="">Giới Thiệu</a></li>
                <li><a href="">Liên hệ</a></li>
                <li><a href="">Góp ý</a></li>
                <li><a href="">Hỏi đáp</a></li>
            </ul>
        </div>
        <div class="row mb ">
            <div class="boxtrai mr ">
                <div class="row">
                    <div class="banner" >
                        <img  alt="" name="img_banner">
                    </div>
                </div>
                <div class="row">
                    <div class="boxsp mr">
                        <img src="img/sp6.PNG" alt="">
                        <p>$30</p>
                        <a href="">Balo mới</a>
                    </div>
                    <div class="boxsp mr">
                        <img src="img/sp2.PNG" alt="">
                        <p>$30</p>
                        <a href="">Balo mới</a>
                    </div>
                    <div class="boxsp mr">
                        <img src="img/sp3.PNG" alt="">
                        <p>$30</p>
                        <a href="">Balo mới</a>
                    </div>
                    <div class="boxsp mr">
                        <img src="img/sp4.PNG" alt="">
                        <p>$30</p>
                        <a href="">Balo mới</a>
                    </div>
                    <div class="boxsp mr">
                        <img src="img/sp5.PNG" alt="">
                        <p>$30</p>
                        <a href="">Balo mới</a>
                    </div>
                    <div class="boxsp mr">
                        <img src="img/sp7.PNG" alt="">
                        <p>$30</p>
                        <a href="">Balo mới</a>
                    </div>
                    <div class="boxsp mr">
                        <img src="img/sp8.PNG" alt="">
                        <p>$30</p>
                        <a href="">Balo mới</a>
                    </div>
                    <div class="boxsp mr">
                        <img src="img/sp9.PNG" alt="">
                        <p>$30</p>
                        <a href="">Balo mới</a>
                    </div>
                    <div class="boxsp ">
                        <img src="img/sp10.PNG" alt="">
                        <p>$30</p>
                        <a href="">Balo mới</a>
                    </div>
                </div>
            </div>
            <div class="boxphai ">
                <div class="row mb  ">
                    <div class="boxtitle">TÀI KHOẢN</div>
                    <div class="boxconten formtk">
                        <form action="" method="post">
                            Tên đặng nhập
                            <br><input type="text" name="">
                            <br>Mật khẩu <br>
                            <input type="password" name=""><br>
                            <br><button type="submit">Đăng nhập</button> <br>
                            <input type="checkbox" name="">Ghi nhớ tài khoản? <br>
                        </form>
                        <li><a href="">Quên mật khẩu</a></li>
                            <li><a href="">Đăng kí</a></li>
                    </div>
                </div>
                <div class="row mb ">
                    <div class="boxtitle">DANH MỤC</div>
                    <div class="boxconten2 menudoc">
                        <ul>
                            <li><a href="">Đồng Hồ</a></li>
                            <li><a href="">Máy tính</a></li>
                            <li><a href="">Balo</a></li>
                            <li><a href="">Điện thoại</a></li>
                            <li><a href="">Laptop</a></li>
                        </ul>
                    </div>
                    <div class="boxfooter">
                        <form action="" method="post">
                            <input type="text" placeholder="Tìm từ khóa ">
                        </form>
                    </div>
                </div>
                <div class="row ">
                    <div class="boxtitle">TOP 10 YÊU THÍCH</div>
                    <div class=" row boxconten">
                        <div class="row mb top10">
                            <img src="img/Layer 19.png" alt="">
                            <a href="">Gucci Bamboo 1947</a>
                        </div>
                        <div class="row mb top10">
                            <img src="img/Layer 20.png" alt="">
                            <a href="">Top handle bag</a>
                        </div>
                        <div class="row mb top10">
                            <img src="img/Layer 21.png" alt="">
                            <a href="">Gucci Bamboo 1947</a>
                        </div>
                        <div class="row mb top10">
                            <img src="img/Layer 22.png" alt="">
                            <a href=""> Belt bag</a>
                        </div>
                        <div class="row mb top10">
                            <img src="img/Layer 23.png" alt="">
                            <a href="">Cotton poplin shirt</a>
                        </div>
                        <div class="row mb top10">
                            <img src="img/Layer 24.png" alt="">
                            <a href="">Gucci Bamboo 1947</a>
                        </div>
                        <div class="row mb top10">
                            <img src="img/Layer 25.png" alt="">
                            <a href="">GG stripe fil coupé cotton shirt</a>
                        </div>
                        <div class="row mb top10">
                            <img src="img/Layer 26.png" alt="">
                            <a href="">Gucci Bamboo 1947</a>
                        </div>
                        <div class="row mb top10">
                            <img src="img/Layer 17.png" alt="">
                            <a href="">Double G cotton striped shirt</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb footer">
            hoangdxph26702
        </div>
    </div>
    <script src="sline.js"></script>
</body> -->