-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th7 21, 2024 lúc 12:52 PM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `quanao`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danhmuc`
--

CREATE TABLE `danhmuc` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `danhmuc`
--

INSERT INTO `danhmuc` (`id`, `name`) VALUES
(88, 'Các Loại Trà'),
(89, 'Bánh Tráng'),
(90, 'Trà Sữa'),
(91, 'Tàu Hũ'),
(92, 'Sữa Chua'),
(93, 'Chè');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `donhang`
--

CREATE TABLE `donhang` (
  `id` int(11) NOT NULL,
  `iduser` int(11) NOT NULL DEFAULT 0,
  `bill_name` varchar(255) NOT NULL,
  `bill_address` varchar(255) NOT NULL,
  `bill_tel` varchar(50) NOT NULL,
  `bill_email` varchar(100) NOT NULL,
  `total` int(11) NOT NULL DEFAULT 0,
  `bill_status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0.Đơn hàng không hợp lệ 1.Chờ kiểm tra 2.Chờ xử lý 3.Đang giao 4.Đã giao hàng',
  `ngaydathang` varchar(50) NOT NULL,
  `receive_name` varchar(255) NOT NULL,
  `receive_address` varchar(255) NOT NULL,
  `receive_tel` varchar(50) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `bank_user` varchar(255) NOT NULL,
  `bank_img` varchar(255) NOT NULL,
  `bank_number` varchar(50) NOT NULL,
  `bank_method` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `donhang`
--

INSERT INTO `donhang` (`id`, `iduser`, `bill_name`, `bill_address`, `bill_tel`, `bill_email`, `total`, `bill_status`, `ngaydathang`, `receive_name`, `receive_address`, `receive_tel`, `bank_name`, `bank_user`, `bank_img`, `bank_number`, `bank_method`) VALUES
(192, 0, 'banh ngot', 'hà nội', '8888888888', 'haivnph37047@fpt.edu.vn', 56000, 4, '12:38:28pm 21/07/2024', '', '', '', 'MB', 'FF', 'cg_0739_4227d41e6f4e486fb679531721703f89_grande.webp', '757776', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `giohang`
--

CREATE TABLE `giohang` (
  `id` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idpro` int(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `soluong` int(3) NOT NULL,
  `thanhtien` int(11) NOT NULL,
  `idbill` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `giohang`
--

INSERT INTO `giohang` (`id`, `iduser`, `idpro`, `img`, `name`, `price`, `soluong`, `thanhtien`, `idbill`) VALUES
(144, 51, 93, 'bag1.png', 'BLACK BLOCK BACKPACK', 250000, 2, 500000, 165);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sanpham`
--

CREATE TABLE `sanpham` (
  `id` int(11) NOT NULL,
  `names` varchar(255) NOT NULL,
  `price` double(10,2) DEFAULT 0.00,
  `img` varchar(255) DEFAULT NULL,
  `mota` text DEFAULT NULL,
  `luotxem` int(11) NOT NULL DEFAULT 0,
  `iddanhmuc` int(11) NOT NULL,
  `soluong` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `sanpham`
--

INSERT INTO `sanpham` (`id`, `names`, `price`, `img`, `mota`, `luotxem`, `iddanhmuc`, `soluong`) VALUES
(99, 'Trà Đào Nhiệt Đới', 25000.00, 'cg_0874_9695a46de6d842cea6a7f71f2adceb2b_grande.webp', 'Trà đào nhiệt đới là một loại đồ uống phổ biến, được làm từ trà đen hoặc trà xanh kết hợp với nước ép đào tươi hoặc siro đào. Thức uống này thường được pha chế lạnh, thường thêm đá viên để tạo cảm giác mát lạnh và sảng khoái. Trà đào nhiệt đới có hương vị ngọt ngào, thơm mát từ đào, thường được trang trí bằng lát đào tươi và lá bạc hà để tăng phần hấp dẫn. Đây là một lựa chọn lý tưởng cho những ngày hè oi bức, giúp giải nhiệt và cung cấp năng lượng.', 0, 88, 1000),
(100, 'Trà Dâu Mộc Châu', 28000.00, 'cg_0827_4ce025b2eed74bdbbabb8b8fcf8c055d_grande.webp', 'Trà dâu Mộc Châu là một loại đồ uống được làm từ trà xanh hoặc trà ô long kết hợp với dâu tươi từ Mộc Châu, một vùng nổi tiếng với những vườn dâu bạt ngàn. Thức uống này mang hương vị thanh mát, chua ngọt tự nhiên từ dâu tươi, hòa quyện với vị chát nhẹ và hương thơm dịu dàng của trà. Trà dâu Mộc Châu thường được phục vụ lạnh, thêm đá viên, và trang trí bằng lát dâu tươi để tạo điểm nhấn hấp dẫn. Đây là một lựa chọn tuyệt vời để thưởng thức trong những ngày hè, giúp giải nhiệt và mang lại cảm giác sảng khoái.', 0, 88, 10),
(101, 'Trà Me Thái', 19000.00, 'cg_0911_f2d90956698e4e7ca6bb362907158bd9_grande.webp', '\r\nTrà me Thái là một loại đồ uống độc đáo và phổ biến tại Thái Lan, được làm từ trà đen kết hợp với hương vị chua ngọt đặc trưng của me. Thức uống này thường được pha chế lạnh, thêm đường hoặc mật ong để tăng độ ngọt, và đá viên để tạo cảm giác mát lạnh. Trà me Thái có hương vị đậm đà, pha lẫn giữa vị chua thanh của me và vị đắng nhẹ của trà, tạo nên một sự kết hợp hài hòa và thú vị. Đây là lựa chọn lý tưởng để giải khát và làm dịu mát trong những ngày nóng bức.', 0, 88, 20),
(103, 'Hồng trà sữa trân châu đen', 26000.00, 'cg_1035_21ec1d2e1f8543a39b5c6b83ca556032_grande.webp', 'hồng trà sữa trân châu đen là một loại đồ uống kết hợp giữa hồng trà và sữa, với trân châu đen làm điểm nhấn. Hồng trà, được pha chế từ lá trà đỏ, tạo nền tảng hương vị phong phú và đậm đà. Khi kết hợp với sữa, đồ uống trở nên mềm mịn và có vị ngọt nhẹ. Trân châu đen, với kết cấu dẻo và hơi ngọt, thêm vào tạo sự thú vị và nhâm nhi cho mỗi ngụm. Được phục vụ lạnh với đá viên, ngăn hồng trà sữa trân châu đen là lựa chọn lý tưởng cho những ai yêu thích sự kết hợp giữa hương vị trà truyền thống và sự ngọt ngào của sữa, cùng với trải nghiệm nhai vui nhộn từ trân châu.', 0, 90, 20),
(104, 'Hồng trà sữa trân châu 3Q', 28000.00, 'chick_0349_4ca2fae113c0481393fa17a66efc74ae_grande.webp', 'Hồng trà sữa trân châu 3Q là một loại đồ uống thú vị kết hợp giữa hồng trà, sữa và ba loại topping đặc biệt: trân châu đen, trân châu trắng và thạch trái cây. Hồng trà mang đến hương vị đậm đà và tinh tế, kết hợp với sữa tạo nên một lớp kem mịn và ngọt ngào. Các topping gồm trân châu đen dẻo, trân châu trắng giòn và thạch trái cây thơm ngon, mang đến sự đa dạng trong kết cấu và hương vị. Được phục vụ lạnh với đá viên, hồng trà sữa trân châu 3Q là sự lựa chọn hoàn hảo cho những ai yêu thích sự kết hợp phong phú và mới mẻ trong một ly trà sữa.', 0, 88, 15),
(105, 'Hồng trà sữa trân châu đen đậu đỏ', 26000.00, 'cg_1035_21ec1d2e1f8543a39b5c6b83ca556032_grande.webp', 'Hồng trà sữa trân châu đen đậu đỏ là một món đồ uống kết hợp giữa hồng trà, sữa, và hai loại topping đặc trưng: trân châu đen và đậu đỏ. Hồng trà mang đến hương vị đậm đà, trong khi sữa làm cho thức uống trở nên mềm mịn và ngọt ngào. Trân châu đen thêm độ dẻo dai và vị ngọt nhẹ, trong khi đậu đỏ cung cấp một lớp kết cấu và vị béo ngậy đặc trưng. Được phục vụ lạnh với đá viên, món trà sữa này mang lại sự hòa quyện hoàn hảo giữa hương vị trà và sữa, cùng với sự thú vị từ các topping.', 0, 88, 10),
(106, 'Hồng trà sữa trân châu đen pudding xoài', 25000.00, 'chick_0356_57ee0ab7f4804ff78c9f1f4d4f68f0ba_grande.webp', ' Hồng trà sữa trân châu đen pudding xoài là một loại đồ uống kết hợp hồng trà và sữa, với các topping đặc biệt gồm trân châu đen và pudding xoài. Hồng trà mang lại hương vị đậm đà và tinh tế, kết hợp với sữa tạo nên một lớp kem mịn và ngọt ngào. Trân châu đen thêm sự dẻo dai và vị ngọt nhẹ, trong khi pudding xoài cung cấp độ mềm mịn và hương vị trái cây tươi mát. Được phục vụ lạnh với đá viên, món trà sữa này mang lại sự hòa quyện thú vị giữa vị trà, sữa và sự phong phú từ các topping.', 0, 90, 10),
(107, 'Hồng trà sữa trân châu đen khoai dẻo', 30000.00, 'chick_0376_3e952bfb167e43f3acaacb8f2384e242_grande.webp', 'Hồng trà sữa trân châu đen khoai dẻo là một món đồ uống kết hợp giữa hồng trà, sữa, trân châu đen và khoai dẻo. Hồng trà tạo nền tảng hương vị đậm đà, hòa quyện với sữa để tạo ra một lớp kem mềm mịn và ngọt ngào. Trân châu đen mang đến độ dẻo dai và vị ngọt nhẹ, trong khi khoai dẻo thêm phần phong phú với kết cấu mềm mịn và vị ngọt tự nhiên. Được phục vụ lạnh với đá viên, món trà sữa này mang lại sự kết hợp hoàn hảo giữa các hương vị và kết cấu, tạo trải nghiệm thú vị và hấp dẫn.', 0, 88, 20),
(108, 'Hồng trà sữa trân châu đen dừa non', 32000.00, 'chick_0376_3e952bfb167e43f3acaacb8f2384e242_grande.webp', 'Hồng trà sữa trân châu đen dừa non', 0, 90, 5);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT 0,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`id`, `user`, `pass`, `email`, `address`, `tel`, `role`, `is_locked`) VALUES
(52, 'admin', 'Vu19072004@', 'vuvannguyen005@gmail.com', 'hà nội', '0943217843', 1, 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `danhmuc`
--
ALTER TABLE `danhmuc`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `donhang`
--
ALTER TABLE `donhang`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `giohang`
--
ALTER TABLE `giohang`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lk_sp_dm` (`iddanhmuc`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `danhmuc`
--
ALTER TABLE `danhmuc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT cho bảng `donhang`
--
ALTER TABLE `donhang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=193;

--
-- AUTO_INCREMENT cho bảng `giohang`
--
ALTER TABLE `giohang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT cho bảng `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `lk_sp_dm` FOREIGN KEY (`iddanhmuc`) REFERENCES `danhmuc` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
