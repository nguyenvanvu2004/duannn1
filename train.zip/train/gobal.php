<?php
$img_path = "upload/";
?>